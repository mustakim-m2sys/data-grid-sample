export class ProcessedError {
    id: string;
    url: string;
    name: any;
    status: any;
    message: any;
    errorDetails: any;
}