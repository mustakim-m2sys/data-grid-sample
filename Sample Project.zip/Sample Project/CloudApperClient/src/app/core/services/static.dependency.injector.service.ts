import { Injector } from "@angular/core";

export class StaticDependencyInjector {
    static Injector: Injector;
}