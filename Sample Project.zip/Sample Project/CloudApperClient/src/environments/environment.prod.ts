export const environment = {
  production: true,
  dev: false,
  hmr: false,
  local: false,
  projectVersion: '5.5.7.3'
};
