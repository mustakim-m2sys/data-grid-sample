export const environment = {
    production: false,
    dev: true,
    hmr: false,
    local: false,
    projectVersion: '5.5.7.3'
};
