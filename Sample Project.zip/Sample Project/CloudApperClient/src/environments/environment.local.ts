export const environment = {
  production: false,
  dev: false,
  hmr: false,
  local: true,
  projectVersion: '5.5.7.3'
};
