export const environment = {
    production: false,
    dev: false,
    hmr: true,
    local: false,
    projectVersion: '5.5.7.3'
};